<?php

$orders_id_string = implode(',',$sync_id);
$hidden_dropdown = '';
if($date_range=='past'){
	$hidden_dropdown = ' style="display:none" ';
}
// BOF sql statement bank

//a
$orders_sql = 'SELECT orders_status,cash_order, categories_id, customers_id, customers_lat, customers_lng, customers_name, customers_telephone, date_deliver, date_purchased, delivery_city, delivery_company, delivery_country, delivery_name, delivery_postcode, delivery_state, delivery_street_address, delivery_suburb, distance_to_deliver, duration_to_deliver, last_modified, orders_id, orders_status, order_total, payment_module_code, updated_from_dispatched, updated_from_future
FROM orders as o where o.orders_id in ('.$orders_id_string.') order by date_deliver desc';

//b
$orders_products_sql='SELECT op.orders_products_id,op.orders_id,op.products_name, op.products_price, op.products_quantity from orders_products as op inner join orders as o on o.orders_id = op.orders_id where o.orders_id in ('.$orders_id_string.') and op.products_model !="BEVERAGE"';

//c
$orders_total_sql='select orders_id,value from orders_total where class="ot_subtotal" and orders_id in ('.$orders_id_string.')';

//d
$orders_products_attributes_sql='select orders_products_id,orders_id,options_values_price,price_prefix,products_options, products_options_values from orders_products_attributes where orders_id in ('.$orders_id_string.')';

//e
$orders_notes = r_select_all_notes($orders_id_string);

//f
$orders_restaurant_adjustment_sql='select orders_id,value from orders_total where class="ot_restaurant_adjustment" and orders_id in ('.$orders_id_string.')';


//BOF sql looping to array
	$a = $db->Execute($orders_sql);
	$order=array();
	while (!$a->EOF){
			$order[]=array('orders_id'=>$a->fields['orders_id'],
							'order_total'=>$a->fields['order_total'],
							'orders_status'=>$a->fields['orders_status'],
							'date_deliver'=>$a->fields['date_deliver']);
		$a->MoveNext();
	}



	$b = $db->Execute($orders_products_sql);
	$orders_products=array();
	while (!$b->EOF){
			$orders_products[$b->fields['orders_id']][]=array('products_name'=>$b->fields['products_name'],'orders_products_id'=>$b->fields['orders_products_id']);
		$b->MoveNext();
	}



	$c = $db->Execute($orders_total_sql);
	$orders_total=array();
	while (!$c->EOF){
			$orders_total[$c->fields['orders_id']]=$c->fields['value'];
		$c->MoveNext();
	}



	$d = $db->Execute($orders_products_attributes_sql);
	$orders_products_attributes=array();
	while (!$d->EOF){
			$orders_products_attributes[$d->fields['orders_products_id']][]=array('products_options'=>$d->fields['products_options'],'products_options_values'=>$d->fields['products_options_values']);
		$d->MoveNext();
	}
	
	
	
	$f = $db->Execute($orders_restaurant_adjustment_sql);
	$orders_restaurant_adjustment=array();
	foreach($sync_id as $o){
		$orders_restaurant_adjustment[$o]=0;
	}
	while (!$f->EOF){
			$orders_restaurant_adjustment[$f->fields['orders_id']]+=$f->fields['value'];
		$f->MoveNext();
	}
	

	$orders_status = r_orders_status(1);


 		$r_table='';
		foreach($order as $o){
       $r_table.='<span id="'.$o['orders_id'].'"
        data-total="'.money_format('%i',$orders_total[$o['orders_id']]).'"
        data-date-deliver="'.$orders_total[$o['orders_id']].'"
        data-adjustment="'.$orders_restaurant_adjustment[$o['orders_id']].'"
        class="orders-object"></span>
		<div id="restaurant-panel-'.$o['orders_id'].'" class="panel panel-default col-md-12 main-panel">
			<div data-drop="'.$o['orders_id'].'" class="panel-heading restaurant-heading">
            	<div class="container-fluid info-fluid">
           			<span class="info-panel col-lg-12 col-md-12 col-sm-12 col-xs-12">
           				<span class="order-id-span col-md-2 col-sm-2 col-xs-2">
							'.$o['orders_id'].'
                   		</span>
						<span class="order-amount-span col-md-2 hidden-xs hidden-sm">
							'.money_format('$%i',$orders_total[$o['orders_id']]).'
                   		</span>
						<span class="order-time-span col-md-2 col-sm-2 col-xs-2">';
						if($o['orders_status']==10){
							$r_table.=date('g:ia m/d/y',strtotime($o['date_deliver']));
						}else{
							$r_table.=date('g:ia',strtotime($o['date_deliver']));
						}
							
                    	$r_table.='</span>';
						if($o['orders_status']!=10){
						$r_table.='<span class="order-status-span status-'.$o['orders_id'].' col-md-2 col-sm-4 col-xs-4">
							'.$orders_status[$o['orders_status']].'
                    	</span>';
						}
						if(true){
						$r_table.='<span class="order-edit-span  col-sm-2 col-sm-offset-2 col-md-2 col-md-offset-2 col-lg-offset-2">
                    		<i class="glyphicon glyphicon-cog gear-cog" data-id="'.$o['orders_id'].'"></i>
                    		</span>';
						}
                    	
       $r_table.='</span>
                </div>
             </div>
              
			 <div class="panel-body restaurant-body '.$o['orders_id'].'" '.$hidden_dropdown.'>
             
             <fieldset>
             <legend>Order</legend>';
				  foreach($orders_products[$o['orders_id']] as $menu_item){ 
                		$r_table.='<div class="col-md-12 col-sm-12 col-xs-12">
							'.$menu_item['products_name'].'
                        </div>';
                         foreach($orders_products_attributes[$menu_item['orders_products_id']] as $attributes){ 
                          		$r_table.='<div class="col-md-6 col-md-offset-1 col-sm-6 col-sm-offset-1 col-xs-6 col-xs-offset-1">
									'.$attributes['products_options_values'].'
                           		</div>';
                          } 
                  }
              $r_table.='</fieldset>';
               
               
                  if(count($orders_notes[$o['orders_id']])>0){ 
               		$r_table.='<fieldset>
              		<legend>Notes</legend>';
               		     foreach($orders_notes[$o['orders_id']] as $notes){   
               					$r_table.='<div class="col-md-12 col-sm-12 col-xs-12">
                        			'.$notes['note'].'
                       			</div>';
              		    } 
               		$r_table.='</fieldset>';
                     }       
             $r_table.='</div>';
             
            
             if(!r_is_confirmed($o['orders_id'])){ 
			    $r_table.='<div id="panel-footer-'.$o['orders_id'].'" class="container-fluid panel-footer '.$o['orders_id'].'" '.$hidden_dropdown.'>
               					<span id="button-panel-'.$o['orders_id'].'" class="button-panel col-md-12">
           	 						<span data-id="'.$o['orders_id'].'" class="btn btn-default col-md-2 col-sm-3 col-xs-3 confirm-btn">
                       					Accept
                   					</span>
             					</span>
						   </div>';
                   } 
           
		 $r_table.='</div>';
		}
$r_table=preg_replace('/\s+/', ' ',$r_table);
?>


