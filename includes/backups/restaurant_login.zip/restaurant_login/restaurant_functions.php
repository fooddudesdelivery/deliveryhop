<?php

function r_orders_status($code=0){
		//g
	global $db;
	$orders_status_sql='select orders_status_id, orders_status_name from orders_status';
	$g = $db->Execute($orders_status_sql);
	$orders_status=array();
	while (!$g->EOF){
			$orders_status[$g->fields['orders_status_id']]=$g->fields['orders_status_name'];
		$g->MoveNext();
	}
	if($code==0){
		echo "<script>window.orders_status=JSON.parse('".json_encode($orders_status)."')</script>";
	}
	
	return $orders_status;
}


function r_confirm($orders_id){
	global $db;
	//!r_is_canceled($orders_id)
	if(true){
		$db->Execute('insert into orders_status_history (orders_status_id,date_added,orders_id) values (4,now(),"'.$orders_id.'")');
		$db->Execute('update orders set orders_status=4 where orders_id="'.$orders_id.'"');
		return 1;
	}else{
		return 0;
	}
	
}

function r_is_confirmed($orders_id){
	global $db;
	$check = r_process_sql_values('select orders_status_id from orders_status_history where orders_id ="'.$orders_id.'"','orders_status_id');
	if(in_array(4,$check)){
		return true;
	}else{
		return false;
	}
}


function r_is_canceled($orders_id){
	global $db;
	$check = r_process_sql_values('select orders_status_id from orders_status_history where orders_id ="'.$orders_id.'"','orders_status_id');
	if(in_array(6,$check)){
		return true;
	}else{
		return false;
	}
}

function r_select_all_notes($where){
	global $db;
	$note_sql=$db->Execute('select order_id,timestamp,note,note_type from notes where order_id in ('.$where.') and note_type=1');
	$note_array=array();
	while(!$note_sql->EOF){
		switch($note_sql->fields['note_type']){
			case 0:$note_type='Driver';
				break;
			case 1:$note_type='Restaurant';
				break;
			case 2:$note_type='Admin';
				break;
			case 3:$note_type='Note about a driver';
				break;
			case 4:$note_type='Customer';
				break;
			default:$note_type='NA';
				break;
		}
		//$zen_com = zen_get_orders_comments($note_sql->fields['order_id']);
		if($zen_com !=''){
			$note_array[$note_sql->fields['order_id']][]=array('timestamp'=>0,'note'=>$zen_com,'note_type'=>1);
		}
		
		$note_array[$note_sql->fields['order_id']][]=array('timestamp'=>$note_sql->fields['timestamp'],'note'=>$note_sql->fields['note'],'note_type'=>$note_type);
		$note_sql->MoveNext();	
	}
	return $note_array;
}

function r_price_change($orders_id,$adjustment,$orders_comments){
	global $db;
	$orders_comments = addslashes(base64_decode($orders_comments).' Adjustment:'.money_format('$%i',$adjustment));
	$adjustment=floatval($adjustment);

	$check_db = $db->Execute('select value,class from orders_total where orders_id="'.(int)$orders_id.'" and class in ("ot_subtotal","ot_total","ot_restaurant_adjustment")');

	while(!$check_db->EOF){
		switch($check_db->fields['class']){
			case 'ot_subtotal':
				$subtotal = $check_db->fields['value'];
				break;
			case 'ot_total':
				$total = $check_db->fields['value'];
				break;
			case 'ot_restaurant_adjustment':
				$adj = floatval($check_db->fields['value']);
				break;
		}
		$check_db->MoveNext();
	}
	
	

	if(!isset($adj)){
		$subtotal+=$adjustment;
		$total+=$adjustment;
		$db->Execute('INSERT INTO orders_total (title,class,sort_order,orders_id,value,text)
VALUES ("Restaurant Adjustment:","ot_restaurant_adjustment","333","'.(int)$orders_id.'","'.$adjustment.'","'.money_format('$%i',$adjustment).'")');
	}else{
		$subtotal=$subtotal-$adj;
		$total=$total-$adj;
		
		$subtotal+=$adjustment;
		$total+=$adjustment;
		$db->Execute('UPDATE orders_total set text="'.money_format('$%i',$adjustment).'",value="'.$adjustment.'" where orders_id="'.(int)$orders_id.'" and class="ot_restaurant_adjustment"');
	}
	
	$db->Execute('UPDATE orders_total set text="'.money_format('$%i',$subtotal).'",value='.$subtotal.' where orders_id="'.(int)$orders_id.'" and class="ot_subtotal"');
	$db->Execute('UPDATE orders_total set text="'.money_format('$%i',$total).'",value='.$total.' where orders_id="'.(int)$orders_id.'" and class="ot_total"');
	$db->Execute('INSERT into notes (note,note_type,order_id,made_by) values ("'.$orders_comments.'","1","'.(int)$orders_id.'","'.$_SESSION['admin_id'].'")');
	return 1;
}


function r_process_sql_values($sql,$col){
	global $db;
	$sql = $db->Execute($sql);
	$array=array();

	while(!$sql->EOF){
		$array[]=$sql->fields[$col];
		$sql->MoveNext();
	}
	return $array;
}

?>