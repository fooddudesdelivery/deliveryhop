<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html dir="ltr" lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">


<meta http-equiv="cache-control" content="max-age=0" />
<meta http-equiv="cache-control" content="no-cache" />
<meta http-equiv="expires" content="0" />
<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
<meta http-equiv="pragma" content="no-cache" />


<link rel="stylesheet" type="text/css" href="includes/restaurant_login/bootstrap.css">
<link rel="stylesheet" type="text/css" href="includes/restaurant_login/daterangepicker-bs3.css" />
<script type="text/javascript" src="includes/restaurant_login/jquery.js"></script>
<script type="text/javascript" src="includes/restaurant_login/bootstrap.js"></script>
<script type="text/javascript" src="includes/restaurant_login/moment.js"></script>
<script type="text/javascript" src="includes/restaurant_login/daterangepicker.js"></script>


<audio id="rocknroll" src="includes/restaurant_login/beep.wav" preload="auto"></audio>
<style>
.order-id-span,.order-time-span,.order-amount-span,.gear-cog,.order-status-span{
	font-size:24px !important;
	line-height:26px;
}
@media screen and (max-width: 500px) {
	.order-id-span,.order-time-span,.order-amount-span,.gear-cog,.order-status-span{
	font-size:18px !important;
	line-height:26px;
	}
}
.order-status-span{
	text-align:right;
}
.info-panel,.restaurant-heading,.modal-section{
	padding-left:0px;
	padding-right:0px;
}
.main-panel{
	padding:0px;
}
.gear-cog{
	float:right;
}
.glyphicon,.input-group-addon,a,.panel-heading{
	cursor:pointer;
}
.modal-section{
	margin-bottom:20px;	
}
#price-change-comment{
	resize: none;
}
body{
	min-height:800px;

}
#time-select{
	display:none;
}

</style>
<script>
window.categories_id = <?php echo $_SESSION['categories_id'] ?>;
$(document).ready(function(e) {
	r_js_sync(JSON.parse('<?php echo json_encode(r_process_sql_values($sync_sql,'orders_id')) ?>'));
//	setInterval(function(){
//		r_play_sound();
//	},3000);
	$(window).unload(function() {
 		document.cookie="page="+window.page+"; path=/";
	});
	
	$(document).on('click','#play_sound',function(){
		android_input('stop');
	});
	$(document).on('click','div.reprint',r_print);
	$(document).on('click','div.restaurant-heading', function() {$('.'+$(this).attr('data-drop')).slideToggle(200);});
	$(document).on('click','i.gear-cog',r_show_modal);
	$(document).on('click','span.confirm-btn',r_confirm_order);
	$(document).on('click','li#past-order-btn',function(){
		window.page='past';
		r_change_date_range(0,0);
		$('#time-select').show();
	});
	$(document).on('click','li#current-order-btn',function(){
		window.page='current';
		r_change_date_range(0,0);
		$('#time-select').hide();
	});
	$('.nav-bar-btn').click(function(){
		$('.nav-bar-btn').removeClass('active');
		$(this).addClass('active');
		$('#navbar').removeClass('in');
	});
	$('#save-btn').click(r_price_change);
	$('.total-change').click(r_total_change);
	$('.applyBtn').click(r_change_date_range);
	$('#options-btn').click(function(){
		$('#config-modal').modal('show');
	});
	if(r_get_cookie('page')!=''){
		window.page=r_get_cookie('page');
		if(window.page!='current'){
			$('#'+window.page+'-order-btn').click();
		}
	}else{
		window.page='current';
	}
	
	function r_print(e){

		var orders_id=$('#modal-order-number').attr('data-id');
		var sync = JSON.stringify({categories_id:window.categories_id,action:'reprint',orders_id:orders_id});
		$.ajax({
			type: 'POST',
			url: "restaurant_index.php",
			data: {sync:sync},
			dataType: 'text',
			success: function(){
				r_alert_show_hide('Reprint Sent');
			},
			error:function(){console.log('error');r_alert_show_hide('Error please try again');}
		});	
	}
	function r_change_date_range(start,end){
		var sync = JSON.stringify({categories_id:window.categories_id,action:'page_change',page:window.page,start_date:start,end_date:end});
		$.ajax({
			type: 'POST',
			url: "restaurant_index.php",
			data: {sync:sync},
			dataType: 'json',
			success: r_change_date_return,
			error:function(){console.log('error');}
		});
		$('#main_order_container').html('');
	}
	function r_change_date_return(data){
		if(data.new_order){
			$('#main_order_container').append(data.new_order);
		}else{
			$('#main_order_container').append('<div class="col-md-12" id="no-orders-text" style="font-size:18px;text-align:center">No orders</div>');
		}
	}
	
	function r_js_sync(id_matrix){
		var sync = JSON.stringify({categories_id:window.categories_id,action:'sync',id_matrix:id_matrix});
		$.ajax({
			type: 'POST',
			url: "restaurant_index.php",
			data: {sync:sync},
			dataType: 'json',
			success: r_js_return,
			error:function(){console.log('error');}
		});
	}
	
	function r_js_return(data){
		if(window.page=='current'){
			if(data.id_matrix){
				$('.orders-object').each(function(index, element) {
           			if(data.id_matrix.indexOf(this.id) == -1){
						$(this).remove();
						$('#restaurant-panel-'+this.id).remove();
					}
        		});	
			}else{
				//$('#main_order_container').text('');
				//$('#main_order_container').append('<div class="col-md-12" id="no-orders-text" style="font-size:18px;text-align:center">No orders</div>');
				
			}
			if(data.sync_status){
				for(var i=0;i<data.sync_status.length;i++){
					$('span.order-status-span.status-'+data.sync_status[i].orders_id).text(window.orders_status[data.sync_status[i].orders_status]);
				}
				
			}
			if(data.new_order){
				r_play_sound();
				$('#main_order_container').append(data.new_order);
			}	
		}else if(window.page=='past'){
			if(data.new_order){
				//r_play_sound();
			}
		}
		setTimeout(function(){
			r_js_sync(data.id_matrix);
		},<?php echo $sync_rate ?>);	
		
	}
	
	function r_confirm_order(){
		var orders_id=$(this).attr('data-id');
		$('#panel-footer-'+orders_id).hide();
		var sync = JSON.stringify({action:'confirm_order',orders_id:orders_id});
		$.ajax({
				type: 'POST',
				url: "restaurant_index.php",
				data: {sync:sync},
				dataType: 'text',
				error: function(){
					r_alert_show_hide('There has been an error please try again');
					$('#button-panel-'+orders_id).show();
				},
				success:function(data){
					if(!data){
						r_alert_show_hide('This order has been canceled');
					}
				}
		});
	}
	
	function r_show_modal(e){
		e.stopPropagation();
		var selected_id = $(this).attr('data-id');
		var data_adjustment = $('#'+selected_id).attr('data-adjustment');
		var data_total = $('#'+selected_id).attr('data-total');
		$('#adjustment-input').val(parseFloat(data_adjustment));
		$('#adjustment-input').attr('data-adjustment',data_adjustment);
		$('#adjustment-input').attr('data-total',data_total);
		$('#modal-order-number').text(selected_id);
		$('#modal-order-number').attr('data-id',selected_id);
		$('#price-modal').modal('show');
	}
	
	function r_total_change(e){

		if(this.id=='increase-total'){
			var adj_amount = 1;
		}else{
			var adj_amount = -1;
		}
		var sentinal = <?php echo $sentinal  ?>;
		var old_total = $('#adjustment-input').attr('data-total');
		var adjustment = parseFloat($('#adjustment-input').attr('data-adjustment'))+adj_amount;
		var abosolute =adjustment/old_total;
		if(abosolute<0){
			abosolute=abosolute*-1;
		}
		if(abosolute > sentinal){
			if(this.id=='increase-total'){
				r_alert_show_hide('You cannot increase the order anymore');
			}else{
				r_alert_show_hide('You cannot decrease the order anymore');
			}
			return;
		}else{
			$('#adjustment-input').val(adjustment.toFixed(2));
			$('#adjustment-input').attr('data-adjustment',adjustment)
		}
	}
	
	function r_play_sound() {	
		android_input('start');
		try{
		document.getElementById('rocknroll').play();
		}catch(e){	
		console.log(e);
		}
	}
	function android_input(string) {
		console.log(string);
        try{
			//Android.receive_input(string);
		}catch(e){
			
		}
    }
	function r_get_cookie(cname) {
    	var name = cname + "=";
    	var ca = document.cookie.split(';');
   		for(var i=0; i<ca.length; i++) {
    	    var c = ca[i];
        	while (c.charAt(0)==' ') c = c.substring(1);
        		if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    		}
   		return '';
	} 
	
	function r_alert_show_hide(txt){
		if(!window.modal_error){
			$('#price-modal-alert').text(txt);
			$('#price-modal-alert').hide();
			$('#price-modal-alert').slideToggle(200);
			window.modal_error = setTimeout(function(){
				$('#price-modal-alert').slideToggle(200);
				delete window.modal_error;
			},5000);
		}
	}
	
	function r_price_change(){
		var orders_id = $('#modal-order-number').attr('data-id');
		var adjustment =parseFloat($('#adjustment-input').val());
		var orders_comment = $('#price-change-comment').val();
		if(orders_comment==''){
			r_alert_show_hide('Please enter a reason for the price change before you save');
			return;
		}
		if(isNaN(adjustment)){
			r_alert_show_hide('Please enter a number');
			return;
		}
		orders_comment = btoa(orders_comment);
		$('#price-change-comment').val('');
		var sync = JSON.stringify({action:'price_change',orders_id:orders_id,adjustment:adjustment,orders_comment:orders_comment});
			$.ajax({
				type: 'POST',
				url: "restaurant_index.php",
				data: {sync:sync},
				dataType: 'text',
				error: function(){
					r_alert_show_hide('There has been an error please try again');
				},
				success: function(data){
					location.reload();
				}
			});
	}
	
	
	
$(function() {
 
    $('#reportrange span').html(moment().subtract(7, 'days').format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));
 
    $('#reportrange').daterangepicker({
        format: 'MM/DD/YYYY',
        startDate: moment().subtract(7, 'days'),
        endDate: moment(),
        minDate: '01/01/2007',
        maxDate: '12/31/2019',
        timePicker: false,
        timePickerIncrement: 1,
        timePicker12Hour: true,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        opens: 'left',
        drops: 'down',
        buttonClasses: ['btn', 'btn-sm'],
        applyClass: 'btn-default',
        cancelClass: 'btn-default',
        separator: ' to ',
        locale: {
            applyLabel: 'Search',
            cancelLabel: 'Cancel',
            fromLabel: 'Start',
            toLabel: 'End',
            customRangeLabel: 'Custom',
            daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr','Sa'],
            monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
            firstDay: 1
        }
    }, function(start, end, label) {
		r_change_date_range(start.toISOString(), end.toISOString());
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    });
 
});


	
});//eof document ready
</script>
</head>